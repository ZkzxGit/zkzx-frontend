import en from './en.json'
import es from './es.json'
import fr from './fr.json'
import ru from './ru.json'
import tr from './tr.json'
import uk from './uk.json'
import zh from './zh.json'
export default {
  en,
  es,
  fr,
  ru,
  tr,
  uk,
  zh
}
