import ru from './ru'
import uk from './uk'
import zh from './zh'

export const locales = [ru, uk, zh]
