<template>
  <AccountPage />
</template>

<script>
import { AccountPage } from '@/modules'

export default {
  components: {
    AccountPage
  }
}
</script>
