<template>
  <div class="compliance">
    <h1 class="title is-size-1 is-size-2-mobile is-spaced">Unavailable For Legal Reasons</h1>
  </div>
</template>

<script>
export default {
  layout: 'geofence'
}
</script>
