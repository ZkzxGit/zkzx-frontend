<template>
  <div class="account-box">
    <Header />
    <Actions />
  </div>
</template>

<script>
import Header from './Header'
import Actions from './Actions'

export default {
  components: {
    Header,
    Actions
  }
}
</script>
