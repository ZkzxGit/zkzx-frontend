export { default as Control } from './Control'
