<template>
  <svg class="arrow" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30.71 150">
    <polygon fill="#000403" points="30.71 0.5 30.34 0.5 0.54 75 30.34 149.5 30.71 149.5 30.71 0.5" />
    <polygon
      class="arrow-border"
      fill="#666"
      points="30.71 149 30.68 149 1.08 75 30.68 1 30.71 1 30.71 0 30 0 0 75 30 150 30.71 150 30.71 149"
    />
  </svg>
</template>
