import LockTab from './LockTab'
import RewardTab from './RewardTab'
import UnlockTab from './UnlockTab'
import DelegateTab from './DelegateTab'
import UndelegateTab from './UndelegateTab'

export { LockTab, RewardTab, UndelegateTab, UnlockTab, DelegateTab }
