import WalletTab from './WalletTab'
import RelayerTab from './RelayerTab'

export { WalletTab, RelayerTab }
