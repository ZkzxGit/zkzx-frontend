import { actions, getters, state, mutations } from '@/modules/account/store'

export { actions, getters, mutations, state }
