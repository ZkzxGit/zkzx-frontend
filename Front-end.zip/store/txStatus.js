const statuses = Object.freeze({
  nonExistent: 0,
  waitingForReciept: 1,
  success: 2,
  fail: 3
})

export default statuses
